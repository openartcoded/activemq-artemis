# Not part of activemq, personal stuff

docker build -f ./docker/Dockerfile-adoptopenjdk-11 -t artcoded/artemis:v2022.0.0 .
docker tag artcoded/artemis:v2022.0.0 artcoded:5000/artcoded/artemis:v2022.0.0
docker push artcoded:5000/artcoded/artemis:v2022.0.0