  # For Debian
  $ docker build -f ./docker/Dockerfile-debian -t artemis-debian .

  # For CentOS
  $ docker build -f ./docker/Dockerfile-centos -t artemis-centos .

  # For AdoptOpen JDK 11
  $ docker build -f ./docker/Dockerfile-adoptopenjdk-11 -t artemis-adoptopenjdk-11 .

  # For AdoptOpen JDK 11 (Build for linux ARMv7/ARM64)
  $ docker buildx build --platform linux/arm64,linux/arm/v7 --push -t {your-repository}/apache-artemis:2.17.0-SNAPSHOT -f ./docker/Dockerfile-adoptopenjdk-11 .
