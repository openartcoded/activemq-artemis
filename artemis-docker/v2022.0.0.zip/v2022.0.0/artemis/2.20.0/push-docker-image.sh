# Not part of activemq, personal stuff
# bash prepare-docker.sh --from-release --artemis-version 2.20.0
# cd _TMP_/artemis/2.20.0

docker build -f ./docker/Dockerfile-adoptopenjdk-11 -t artcoded/artemis:v2022.0.0 .
docker tag artcoded/artemis:v2022.0.0 artcoded:5000/artcoded/artemis:v2022.0.0
docker push artcoded:5000/artcoded/artemis:v2022.0.0